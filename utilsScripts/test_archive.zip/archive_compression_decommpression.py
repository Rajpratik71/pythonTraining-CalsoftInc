import os
import shutil
import zipfile

if os.path.exists('testfile'):
    src = os.path.realpath('testfile');
    os.rename("testfile","new_test")
    root_dir,tail = os.path.split(src)
    shutil.make_archive("test_archive","zip",root_dir)

    with zipfile("test.zip","w") as newzip:
        newzip.write("testfile")
        newzip.write("new_test")
